#!/usr/bin/env bash
# Run the Table 7 ablation grid, or a chosen subset of it.
#
#   bash run_ablation.sh                              # all 13 rows, seeds 0-9
#   bash run_ablation.sh --variants full i ii         # selected rows
#   bash run_ablation.sh --seeds 0 1 2                # fewer seeds
#   bash run_ablation.sh --dry-run                    # print the commands only
#
# Each variant is run on the cohort named in its own config (D1 for (x),
# D3 for (xi), D4 for the rest), exactly as Table 7 reports it. After the grid
# finishes, aggregate with:
#   python evaluate_all.py --results results --out tables --stats
set -euo pipefail

cd "$(dirname "$0")"

ALL_VARIANTS=(full i ii iii iv v vi vii viii ix x xi xii)
VARIANTS=("${ALL_VARIANTS[@]}")
SEEDS=(0 1 2 3 4 5 6 7 8 9)
DATA_ROOT="./data"
OUT_DIR="./results"
DEVICE=""
DRY_RUN=0

usage() { sed -n '2,14p' "$0"; exit "${1:-0}"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --variants) shift; VARIANTS=(); while [[ $# -gt 0 && "$1" != --* ]]; do VARIANTS+=("$1"); shift; done ;;
    --seeds)    shift; SEEDS=();    while [[ $# -gt 0 && "$1" != --* ]]; do SEEDS+=("$1"); shift; done ;;
    --data-root) DATA_ROOT="$2"; shift 2 ;;
    --out-dir)   OUT_DIR="$2";   shift 2 ;;
    --device)    DEVICE="$2";    shift 2 ;;
    --dry-run)   DRY_RUN=1; shift ;;
    -h|--help)   usage 0 ;;
    *) echo "unknown option: $1" >&2; usage 1 ;;
  esac
done

if [[ ${#VARIANTS[@]} -eq 0 || ${#SEEDS[@]} -eq 0 ]]; then
  echo "no variants or no seeds selected" >&2; exit 1
fi

PY=${PYTHON:-python3}
total=$(( ${#VARIANTS[@]} * ${#SEEDS[@]} ))
i=0
failed=()

for v in "${VARIANTS[@]}"; do
  cfg="configs/ablations/ablation_${v}.yaml"
  if [[ ! -f "$cfg" ]]; then
    echo "missing config: $cfg" >&2; failed+=("$v/config"); continue
  fi
  for s in "${SEEDS[@]}"; do
    i=$(( i + 1 ))
    cmd=("$PY" train.py --config "$cfg" --seed "$s"
         --data-root "$DATA_ROOT" --out-dir "$OUT_DIR")
    [[ -n "$DEVICE" ]] && cmd+=(--device "$DEVICE")
    echo "[$i/$total] ${cmd[*]}"
    if [[ $DRY_RUN -eq 0 ]]; then
      "${cmd[@]}" || failed+=("$v/seed$s")
    fi
  done
done

if [[ ${#failed[@]} -gt 0 ]]; then
  echo "failed runs: ${failed[*]}" >&2; exit 1
fi

echo
echo "grid complete. Aggregate with:"
echo "  $PY evaluate_all.py --results $OUT_DIR --out tables --stats"
