#!/usr/bin/env python3
"""Regenerate Figures 5 and 6 from the values in manuscript_values.py.

    python make_figures.py --out figures --dpi 600

Figure 5  main performance comparison: seven methods across D1-D4 and the three
          primary metrics reported for each cohort (AUROC and macro-F1
          everywhere; MRR for D1 and D4; P@50 for D2 and D3).
Figure 6  ablation study: the Table 7 variants on their own cohorts.

Methods and variants are distinguished by colour and by hatch pattern, so the
panels stay readable in greyscale and for colour-vision-deficient readers, as
the figure captions state. Bar heights and error bars are the means and
standard deviations transcribed in manuscript_values.py; nothing is simulated.
"""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from manuscript_values import TABLE6, TABLE7, DATASETS, THIRD_METRIC
from src.metrics import METRIC_LABELS

ORDER = ["DeepARG", "TransAMR", "AMR-GNN", "HetGAT-TB", "MDGNN",
         "MetaTransformer", "PanMetaGraph"]
COHORT = {"D1": "D1 (HGR)", "D2": "D2 (GUS)", "D3": "D3 (IMW)", "D4": "D4 (GCM)"}
COLOR = {"DeepARG": "#9e9e9e", "TransAMR": "#bdbdbd", "AMR-GNN": "#6baed6",
         "HetGAT-TB": "#9ecae1", "MDGNN": "#c6dbef", "MetaTransformer": "#4292c6",
         "PanMetaGraph": "#1f4e79"}
HATCH = {"DeepARG": "//", "TransAMR": "\\\\", "AMR-GNN": "..", "HetGAT-TB": "xx",
         "MDGNN": "--", "MetaTransformer": "++", "PanMetaGraph": ""}

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8,
                     "axes.linewidth": 0.6, "hatch.linewidth": 0.5})


def figure5(out, dpi):
    fig, axes = plt.subplots(1, 4, figsize=(11.0, 3.1), sharey=True)
    for ax, ds in zip(axes, DATASETS):
        mets = ["auroc", "macro_f1", THIRD_METRIC[ds]]
        x = np.arange(len(mets))
        w = 0.115
        for i, meth in enumerate(ORDER):
            vals = [TABLE6[meth][ds][m][0] for m in mets]
            errs = [TABLE6[meth][ds][m][1] for m in mets]
            ax.bar(x + (i - 3) * w, vals, w, yerr=errs, capsize=1.4,
                   color=COLOR[meth], hatch=HATCH[meth],
                   edgecolor="black" if meth != "PanMetaGraph" else "black",
                   linewidth=1.1 if meth == "PanMetaGraph" else 0.4,
                   error_kw={"elinewidth": 0.5, "capthick": 0.5},
                   label=meth if ds == "D1" else None)
        ax.set_xticks(x)
        ax.set_xticklabels([METRIC_LABELS[m] for m in mets])
        ax.set_title(COHORT[ds], fontsize=8.5)
        ax.set_ylim(0.60, 1.0)
        ax.grid(axis="y", lw=0.3, alpha=0.5)
        ax.set_axisbelow(True)
        ax.tick_params(length=2)
    axes[0].set_ylabel("Score")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=7, frameon=False,
               fontsize=7.4, bbox_to_anchor=(0.5, -0.03))
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    p = Path(out) / "figure5_main_comparison.png"
    fig.savefig(p, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return p


def figure6(out, dpi):
    ids = ["full", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii"]
    short = {"full": "Full", "i": "(i)\nw/o PPE", "ii": "(ii)\nw/o MGE", "iii": "(iii)\nw/o Eco",
             "iv": "(iv)\nGCN", "v": "(v)\nLinear Ref", "vi": "(vi)\nw/o TPR",
             "vii": "(vii)\nSin PE", "viii": "(viii)\nGAT", "ix": "(ix)\nFixed w",
             "x": "(x)\nD1 only", "xi": "(xi)\nD3 only", "xii": "(xii)\nBackbone"}
    mets = [("AUROC", 2), ("Macro-F1", 4), ("P@50", 6)]
    fig, ax = plt.subplots(figsize=(10.4, 3.4))
    x = np.arange(len(ids))
    w = 0.26
    cols = ["#1f4e79", "#6baed6", "#c6dbef"]
    hats = ["", "//", ".."]
    for j, (name, idx) in enumerate(mets):
        vals = [TABLE7[v][idx] for v in ids]
        xs = [x[k] + (j - 1) * w for k, v in enumerate(ids) if vals[k] is not None]
        ys = [v for v in vals if v is not None]
        ax.bar(xs, ys, w, color=cols[j], hatch=hats[j], edgecolor="black",
               linewidth=0.4, label=name)
    for k, v in enumerate(ids):
        if TABLE7[v][6] is None:
            ax.text(x[k] + w, 0.615, "n/a", ha="center", va="bottom", fontsize=6,
                    color="#555555", rotation=90)
    ax.axhline(TABLE7["full"][2], color="#1f4e79", lw=0.6, ls="--", alpha=0.7)
    ax.set_xticks(x)
    ax.set_xticklabels([short[v] for v in ids], fontsize=6.6)
    ax.set_ylim(0.60, 1.0)
    ax.set_ylabel("Score")
    ax.grid(axis="y", lw=0.3, alpha=0.5)
    ax.set_axisbelow(True)
    ax.tick_params(length=2)
    ax.legend(frameon=False, ncol=3, fontsize=7.4, loc="upper right")
    ax.set_title("Ablation variants: (i)-(ix) and (xii) on D4, (x) on D1, (xi) on D3",
                 fontsize=8.5)
    fig.tight_layout()
    p = Path(out) / "figure6_ablation.png"
    fig.savefig(p, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="figures")
    ap.add_argument("--dpi", type=int, default=600)
    a = ap.parse_args()
    Path(a.out).mkdir(parents=True, exist_ok=True)
    for p in (figure5(a.out, a.dpi), figure6(a.out, a.dpi)):
        print("wrote", p)


if __name__ == "__main__":
    main()
