"""Single source of truth: every value here is transcribed verbatim from the
manuscript tables. generate_expected.py, verify_against_manuscript.py and
make_figures.py all read from this module so that the package and the paper
cannot drift apart.

Source: PanMetaGraph, MDPI Bioengineering submission.
  TABLE6  -> Table 6 (main performance comparison)
  TABLE7  -> Table 7 (ablation study)
  TABLE8  -> Table 8 (statistical significance vs AMR-GNN)
  TABLE9  -> Table 9 (graph statistics and per-dataset cost)
  TABLE10 -> Table 10 (computational cost comparison on D4)
"""

DATASETS = ["D1", "D2", "D3", "D4"]
# the third primary metric differs by cohort, exactly as reported in Table 6
THIRD_METRIC = {"D1": "mrr", "D2": "p_at_50", "D3": "p_at_50", "D4": "mrr"}
PRIMARY = ["auroc", "macro_f1", "third"]
SECONDARY = ["pr_auc", "mcc"]

# (mean, sd) per metric
TABLE6 = {
 "DeepARG": {
  "D1": {"auroc":(0.831,0.008),"macro_f1":(0.744,0.009),"mrr":(0.692,0.011),"pr_auc":(0.761,0.009),"mcc":(0.682,0.010)},
  "D2": {"auroc":(0.849,0.007),"macro_f1":(0.771,0.008),"p_at_50":(0.813,0.009),"pr_auc":(0.792,0.008),"mcc":(0.714,0.009)},
  "D3": {"auroc":(0.818,0.009),"macro_f1":(0.729,0.010),"p_at_50":(0.794,0.011),"pr_auc":(0.748,0.010),"mcc":(0.671,0.011)},
  "D4": {"auroc":(0.843,0.007),"macro_f1":(0.762,0.008),"mrr":(0.718,0.009),"pr_auc":(0.779,0.008),"mcc":(0.703,0.009)}},
 "TransAMR": {
  "D1": {"auroc":(0.862,0.007),"macro_f1":(0.779,0.008),"mrr":(0.775,0.009),"pr_auc":(0.798,0.008),"mcc":(0.721,0.009)},
  "D2": {"auroc":(0.873,0.006),"macro_f1":(0.793,0.007),"p_at_50":(0.841,0.008),"pr_auc":(0.821,0.007),"mcc":(0.742,0.008)},
  "D3": {"auroc":(0.851,0.007),"macro_f1":(0.767,0.008),"p_at_50":(0.831,0.009),"pr_auc":(0.784,0.008),"mcc":(0.708,0.009)},
  "D4": {"auroc":(0.871,0.006),"macro_f1":(0.801,0.007),"mrr":(0.757,0.008),"pr_auc":(0.812,0.007),"mcc":(0.736,0.008)}},
 "AMR-GNN": {
  "D1": {"auroc":(0.891,0.006),"macro_f1":(0.812,0.007),"mrr":(0.794,0.008),"pr_auc":(0.824,0.007),"mcc":(0.748,0.008)},
  "D2": {"auroc":(0.907,0.005),"macro_f1":(0.831,0.006),"p_at_50":(0.871,0.006),"pr_auc":(0.889,0.006),"mcc":(0.781,0.007)},
  "D3": {"auroc":(0.889,0.006),"macro_f1":(0.822,0.007),"p_at_50":(0.869,0.007),"pr_auc":(0.836,0.007),"mcc":(0.764,0.008)},
  "D4": {"auroc":(0.914,0.005),"macro_f1":(0.847,0.006),"mrr":(0.799,0.007),"pr_auc":(0.859,0.005),"mcc":(0.791,0.006)}},
 "HetGAT-TB": {
  "D1": {"auroc":(0.876,0.007),"macro_f1":(0.797,0.008),"mrr":(0.781,0.009),"pr_auc":(0.809,0.008),"mcc":(0.732,0.009)},
  "D2": {"auroc":(0.893,0.006),"macro_f1":(0.818,0.007),"p_at_50":(0.857,0.008),"pr_auc":(0.841,0.007),"mcc":(0.758,0.008)},
  "D3": {"auroc":(0.874,0.007),"macro_f1":(0.809,0.008),"p_at_50":(0.851,0.009),"pr_auc":(0.821,0.008),"mcc":(0.746,0.009)},
  "D4": {"auroc":(0.901,0.006),"macro_f1":(0.831,0.007),"mrr":(0.785,0.008),"pr_auc":(0.843,0.007),"mcc":(0.772,0.008)}},
 "MDGNN": {
  "D1": {"auroc":(0.864,0.007),"macro_f1":(0.783,0.008),"mrr":(0.769,0.009),"pr_auc":(0.794,0.008),"mcc":(0.718,0.009)},
  "D2": {"auroc":(0.881,0.006),"macro_f1":(0.807,0.007),"p_at_50":(0.844,0.008),"pr_auc":(0.828,0.007),"mcc":(0.746,0.008)},
  "D3": {"auroc":(0.862,0.007),"macro_f1":(0.793,0.008),"p_at_50":(0.837,0.009),"pr_auc":(0.806,0.008),"mcc":(0.731,0.009)},
  "D4": {"auroc":(0.888,0.006),"macro_f1":(0.819,0.007),"mrr":(0.771,0.008),"pr_auc":(0.829,0.007),"mcc":(0.759,0.008)}},
 "MetaTransformer": {
  "D1": {"auroc":(0.883,0.006),"macro_f1":(0.804,0.007),"mrr":(0.788,0.008),"pr_auc":(0.816,0.007),"mcc":(0.739,0.008)},
  "D2": {"auroc":(0.901,0.005),"macro_f1":(0.827,0.006),"p_at_50":(0.864,0.007),"pr_auc":(0.852,0.006),"mcc":(0.769,0.007)},
  "D3": {"auroc":(0.882,0.006),"macro_f1":(0.817,0.007),"p_at_50":(0.862,0.008),"pr_auc":(0.831,0.007),"mcc":(0.754,0.008)},
  "D4": {"auroc":(0.907,0.005),"macro_f1":(0.841,0.006),"mrr":(0.793,0.007),"pr_auc":(0.851,0.006),"mcc":(0.781,0.007)}},
 "PanMetaGraph": {
  "D1": {"auroc":(0.943,0.004),"macro_f1":(0.869,0.005),"mrr":(0.847,0.006),"pr_auc":(0.881,0.005),"mcc":(0.812,0.006)},
  "D2": {"auroc":(0.958,0.004),"macro_f1":(0.877,0.005),"p_at_50":(0.924,0.005),"pr_auc":(0.941,0.004),"mcc":(0.841,0.005)},
  "D3": {"auroc":(0.951,0.005),"macro_f1":(0.883,0.006),"p_at_50":(0.917,0.006),"pr_auc":(0.897,0.005),"mcc":(0.826,0.006)},
  "D4": {"auroc":(0.961,0.003),"macro_f1":(0.891,0.004),"mrr":(0.853,0.005),"pr_auc":(0.903,0.004),"mcc":(0.834,0.005)}},
}

# variant id -> (label, dataset, auroc, d_auroc, macro_f1, d_f1, p_at_50, d_p50)
TABLE7 = {
 "full":  ("Full PanMetaGraph","D4",0.961,None,0.891,None,0.924,None),
 "i":     ("(i) w/o PPE","D4",0.929,-0.032,0.858,-0.033,0.891,-0.033),
 "ii":    ("(ii) w/o MGE edges","D4",0.936,-0.025,0.863,-0.028,0.897,-0.027),
 "iii":   ("(iii) w/o Eco edges","D4",0.942,-0.019,0.872,-0.019,0.903,-0.021),
 "iv":    ("(iv) GCN variant","D4",0.917,-0.044,0.843,-0.048,0.876,-0.048),
 "v":     ("(v) Linear Ref alignment","D4",0.910,-0.051,0.836,-0.055,0.869,-0.055),
 "vi":    ("(vi) w/o TPR","D4",0.948,-0.013,0.874,-0.017,0.908,-0.016),
 "vii":   ("(vii) Sinusoidal PE (replace PPE)","D4",0.934,-0.027,0.861,-0.030,0.893,-0.031),
 "viii":  ("(viii) GAT encoder (replace transformer)","D4",0.923,-0.038,0.849,-0.042,0.881,-0.043),
 "ix":    ("(ix) Fixed edge weights, no learned beta_r","D4",0.939,-0.022,0.866,-0.025,0.899,-0.025),
 "x":     ("(x) w/o MGE edges (D1 only)","D1",0.921,-0.022,0.847,-0.022,None,None),
 "xi":    ("(xi) w/o Eco edges (D3 only)","D3",0.931,-0.020,0.861,-0.022,None,None),
 "xii":   ("(xii) Backbone only (w/o MGE + Eco)","D4",0.904,-0.057,0.831,-0.060,0.862,-0.062),
}

# (dataset, metric, panmetagraph, amr_gnn, diff, ci_low, ci_high)
TABLE8 = [
 ("D1","auroc",(0.943,0.004),(0.891,0.006),0.052,0.047,0.057),
 ("D1","macro_f1",(0.869,0.005),(0.812,0.007),0.057,0.051,0.063),
 ("D1","pr_auc",(0.881,0.005),(0.824,0.007),0.057,0.051,0.063),
 ("D2","auroc",(0.958,0.004),(0.907,0.005),0.051,0.046,0.056),
 ("D2","p_at_50",(0.924,0.005),(0.871,0.006),0.053,0.047,0.059),
 ("D2","pr_auc",(0.941,0.004),(0.889,0.006),0.052,0.047,0.057),
 ("D3","auroc",(0.951,0.005),(0.889,0.006),0.062,0.056,0.068),
 ("D3","macro_f1",(0.883,0.006),(0.822,0.007),0.061,0.054,0.068),
 ("D3","pr_auc",(0.897,0.005),(0.836,0.007),0.061,0.055,0.067),
 ("D4","auroc",(0.961,0.003),(0.914,0.005),0.047,0.043,0.051),
 ("D4","macro_f1",(0.891,0.004),(0.847,0.006),0.044,0.039,0.049),
 ("D4","pr_auc",(0.903,0.004),(0.859,0.005),0.044,0.039,0.049),
]

# method -> (params_millions, train_min_per_epoch, inference_us)
TABLE10 = {"DeepARG":(4.1,2.3,31),"TransAMR":(6.8,3.1,47),"AMR-GNN":(9.2,4.7,58),
          "HetGAT-TB":(8.4,4.3,54),"MDGNN":(7.9,4.0,51),"MetaTransformer":(11.3,5.2,64),
          "PanMetaGraph":(12.7,6.6,79)}

# dataset -> (nodes, edges, node_types, edge_types, train_min_per_epoch,
#              peak_gpu_gb_4devices, total_train_hrs_10_seeds, inference_us)
TABLE9 = {"D1": (1847312, 11284601, 4, 4, 4.2, 31.4, 70.0, 79),
          "D2": (2614887, 16923445, 4, 4, 5.1, 47.2, 85.0, 79),
          "D3": (412063,   2871204, 4, 4, 1.8, 12.6, 30.0, 79),
          "D4": (3187409, 19712883, 4, 4, 6.6, 62.8, 110.0, 79)}
EPOCHS_MAX = 100          # Table 5 "Max epochs T"; total hrs = epochs*seeds*min/60

# dataset sizes used in the manuscript (Table 3 and Section 6.1/6.3)
RUNS       = {"D1":286997,"D2":5765,"D3":447,"D4":104266}
MAGS       = {"D1":204938,"D2":1243800,"D3":69248,"D4":387451}
MAGS_MASH  = {"D1":203091,"D2":1240388,"D3":69050,"D4":385348}
