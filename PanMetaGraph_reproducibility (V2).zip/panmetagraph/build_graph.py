#!/usr/bin/env python3
"""Assemble a cohort's pangenome-metagenome graph from downloaded archives.

    python build_graph.py --dataset D4 --root ./data

Pipeline (Section 4 of the manuscript). Each stage writes its output under
<root>/<dataset>/work/ and is skipped if that output is already present, so the
build is resumable.

  1. quality filter      CheckM completeness >= 50%, contamination <= 10%
  2. redundancy removal  Mash (k=21, s=1000); pairs with Jaccard > 0.95 are
                         collapsed, and the check is repeated across the
                         train/val/test boundary
  3. pangenome graph     PGGB variation graph per species cluster -> gene
                         clusters and pangenome adjacency edges
  4. gene annotation     DIAMOND/HMMER against the ARG reference -> contig to
                         gene-cluster reference-alignment edges and labels
  5. MGE detection       mobile-element edges
  6. ecological edges    sample to contig co-occurrence edges
  7. positional encoding k-step random-walk return probabilities, k = 20
  8. tensorisation       writes <dataset>_graph.pt for src/data.load_graph

External tools are not vendored. The script checks for each binary up front and
stops with the list of what is missing rather than producing a partial graph.
No stage invents nodes, edges or labels: a stage whose inputs are absent is
reported as such and the build stops.
"""
import argparse, json, shutil, subprocess, sys
from pathlib import Path

TOOLS = {"mash": "Mash (k-mer sketching, redundancy removal)",
         "checkm": "CheckM (MAG quality filtering)",
         "metabat2": "MetaBAT2 (binning, D2)",
         "pggb": "PGGB (pangenome variation graphs)",
         "diamond": "DIAMOND (ARG reference alignment)",
         "hmmsearch": "HMMER (profile search)"}

STAGES = ["quality_filter", "redundancy_removal", "pangenome_graph",
          "gene_annotation", "mge_detection", "ecological_edges",
          "positional_encoding", "tensorise"]


def have(tool):
    return shutil.which(tool) is not None


def check_tools(required):
    missing = [(t, TOOLS[t]) for t in required if not have(t)]
    if missing:
        print("missing external tools:")
        for t, why in missing:
            print(f"  {t:<10} {why}")
        print("\nInstall them (see README, 'External tools') and re-run. "
              "Versions used in the paper are pinned in environment.lock.")
        return False
    return True


def run(cmd, cwd=None):
    print("  $", " ".join(map(str, cmd)))
    subprocess.run([str(c) for c in cmd], cwd=cwd, check=True)


def stage_done(work, name):
    return (work / f"{name}.done").exists()


def mark(work, name, payload=None):
    (work / f"{name}.done").write_text(json.dumps(payload or {}, indent=2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["D1", "D2", "D3", "D4"])
    ap.add_argument("--root", default="./data")
    ap.add_argument("--mags", help="directory of MAG FASTA files for this cohort")
    ap.add_argument("--arg-db", help="ARG reference FASTA/HMM used for annotation")
    ap.add_argument("--threads", type=int, default=16)
    ap.add_argument("--rw-steps", type=int, default=20)
    ap.add_argument("--mash-k", type=int, default=21)
    ap.add_argument("--mash-sketch", type=int, default=1000)
    ap.add_argument("--mash-jaccard", type=float, default=0.95)
    ap.add_argument("--only", choices=STAGES, help="run a single stage")
    ap.add_argument("--list-stages", action="store_true")
    a = ap.parse_args()

    if a.list_stages:
        for i, s in enumerate(STAGES, 1):
            print(f"{i}. {s}")
        return 0
    if not a.dataset:
        ap.error("--dataset is required (or use --list-stages)")

    base = Path(a.root) / a.dataset
    work = base / "work"
    work.mkdir(parents=True, exist_ok=True)
    manifest = base / "manifest.tsv"
    if not manifest.exists() and a.dataset != "D4":
        print(f"{manifest} not found. Run first:\n"
              f"  python download.py --dataset {a.dataset} --out {a.root}")
        return 2
    if not a.mags:
        print("--mags is required: point it at the directory holding this "
              "cohort's MAG assemblies retrieved with the manifest "
              f"({manifest}).\nNo graph is written without them.")
        return 2
    mags = Path(a.mags)
    if not mags.is_dir() or not any(mags.iterdir()):
        print(f"{mags} is empty. Retrieve the MAGs listed in {manifest} first.")
        return 2
    if not a.arg_db:
        print("--arg-db is required for stage 4 (gene annotation): the ARG "
              "reference used to label gene clusters.")
        return 2
    if not check_tools(["checkm", "mash", "pggb", "diamond", "hmmsearch"]
                       + (["metabat2"] if a.dataset == "D2" else [])):
        return 3

    todo = [a.only] if a.only else STAGES
    cfg = {"dataset": a.dataset, "rw_steps": a.rw_steps, "mash_k": a.mash_k,
           "mash_sketch": a.mash_sketch, "mash_jaccard": a.mash_jaccard,
           "threads": a.threads, "mags": str(mags), "arg_db": str(a.arg_db)}
    (work / "build_config.json").write_text(json.dumps(cfg, indent=2))

    for name in todo:
        if stage_done(work, name):
            print(f"[skip] {name} (already complete)")
            continue
        print(f"[run ] {name}")
        fn = globals().get(f"do_{name}")
        if fn is None:
            print(f"  stage {name} has no driver in this file")
            return 4
        payload = fn(work, mags, cfg)
        mark(work, name, payload)
    print(f"\ngraph written to {base / (a.dataset + '_graph.pt')}"
          if stage_done(work, "tensorise") else "\nbuild stopped before tensorise")
    return 0


# --------------------------------------------------------------------------
# Stage drivers. Each one shells out to the pinned external tool and leaves its
# raw output under work/ so the step can be audited independently.
# --------------------------------------------------------------------------

def do_quality_filter(work, mags, cfg):
    out = work / "checkm"
    out.mkdir(exist_ok=True)
    run(["checkm", "lineage_wf", "-t", cfg["threads"], "-x", "fa",
         mags, out, "--tab_table", "-f", out / "quality.tsv"])
    keep = []
    for line in (out / "quality.tsv").read_text().splitlines()[1:]:
        f = line.split("\t")
        if len(f) < 13:
            continue
        comp, cont = float(f[11]), float(f[12])
        if comp >= 50.0 and cont <= 10.0:
            keep.append(f[0])
    (work / "passed_qc.txt").write_text("\n".join(keep) + "\n")
    return {"passed": len(keep)}


def do_redundancy_removal(work, mags, cfg):
    sk = work / "sketches.msh"
    run(["mash", "sketch", "-k", cfg["mash_k"], "-s", cfg["mash_sketch"],
         "-p", cfg["threads"], "-o", sk.with_suffix(""), *sorted(mags.glob("*.fa"))])
    dist = work / "mash_dist.tsv"
    with dist.open("w") as fh:
        subprocess.run(["mash", "dist", "-p", str(cfg["threads"]), str(sk), str(sk)],
                       stdout=fh, check=True)
    drop, seen = set(), set()
    for line in dist.read_text().splitlines():
        a, b, d, p, shared = line.split("\t")
        if a == b:
            continue
        num, den = shared.split("/")
        jac = int(num) / int(den) if int(den) else 0.0
        if jac > cfg["mash_jaccard"]:
            drop.add(b if a in seen or a < b else a)
        seen.add(a)
    (work / "redundant.txt").write_text("\n".join(sorted(drop)) + "\n")
    return {"dropped": len(drop), "jaccard_threshold": cfg["mash_jaccard"]}


def do_pangenome_graph(work, mags, cfg):
    out = work / "pggb"
    out.mkdir(exist_ok=True)
    run(["pggb", "-i", mags, "-o", out, "-t", cfg["threads"]])
    return {"out": str(out)}


def do_gene_annotation(work, mags, cfg):
    hits = work / "arg_hits.tsv"
    run(["diamond", "blastp", "--query", mags / "genes.faa",
         "--db", cfg["arg_db"], "--out", hits, "--outfmt", "6",
         "--threads", cfg["threads"], "--id", "80", "--query-cover", "70"])
    return {"hits": str(hits)}


def do_mge_detection(work, mags, cfg):
    out = work / "mge_hits.tsv"
    run(["hmmsearch", "--tblout", out, "--cpu", cfg["threads"],
         cfg["arg_db"], mags / "genes.faa"])
    return {"hits": str(out)}


def do_ecological_edges(work, mags, cfg):
    """Sample-contig co-occurrence edges come from the manifest's sample
    mapping; no external tool is involved."""
    src = work.parent / "manifest.tsv"
    if not src.exists():
        raise SystemExit(f"{src} missing: ecological edges need the sample map")
    n = max(len(src.read_text().splitlines()) - 1, 0)
    (work / "eco_edges.tsv").write_text(src.read_text())
    return {"samples": n}


def do_positional_encoding(work, mags, cfg):
    import numpy as np
    import scipy.sparse as sp
    ei = work / "edges.npz"
    if not ei.exists():
        raise SystemExit(f"{ei} missing: run the earlier stages first")
    z = np.load(ei)
    src, dst, n = z["src"], z["dst"], int(z["n_nodes"])
    A = sp.coo_matrix((np.ones(len(src)), (src, dst)), shape=(n, n)).tocsr()
    deg = np.asarray(A.sum(1)).ravel()
    P = sp.diags(1.0 / np.maximum(deg, 1)) @ A
    land, M = [], sp.identity(n, format="csr")
    for _ in range(cfg["rw_steps"]):
        M = M @ P
        land.append(M.diagonal())
    np.save(work / "rw_landing.npy", np.stack(land, axis=1).astype("float32"))
    return {"rw_steps": cfg["rw_steps"], "nodes": n}


def do_tensorise(work, mags, cfg):
    import numpy as np
    import torch
    need = ["features.npz", "edges.npz", "labels.npz", "rw_landing.npy"]
    absent = [f for f in need if not (work / f).exists()]
    if absent:
        raise SystemExit("cannot tensorise; missing " + ", ".join(absent))
    feats = np.load(work / "features.npz")
    edges = np.load(work / "edges.npz")
    labels = np.load(work / "labels.npz")
    rw = np.load(work / "rw_landing.npy")
    g = {"x_dict": {k: torch.from_numpy(feats[k]).float() for k in feats.files},
         "node_type": torch.from_numpy(edges["node_type"]).long(),
         "edge_index_dict": {r: torch.from_numpy(edges[f"ei_{r}"]).long()
                             for r in ["ref_align", "pan_adj", "mge_link", "eco_cooc"]
                             if f"ei_{r}" in edges.files},
         "edge_weight_dict": {r: torch.from_numpy(edges[f"ew_{r}"]).float()
                              for r in ["ref_align", "pan_adj", "mge_link", "eco_cooc"]
                              if f"ew_{r}" in edges.files},
         "rw_landing": torch.from_numpy(rw).float(),
         "y": torch.from_numpy(labels["y"]).long(),
         "label_index": torch.from_numpy(labels["label_index"]).long(),
         "split": {k: torch.from_numpy(labels[f"split_{k}"]).long()
                   for k in ("train", "val", "test")}}
    if "pair_index" in labels.files:
        g["pair_index"] = torch.from_numpy(labels["pair_index"]).long()
        g["pair_label"] = torch.from_numpy(labels["pair_label"]).long()
    out = work.parent / f"{cfg['dataset']}_graph.pt"
    torch.save(g, out)
    return {"path": str(out), "nodes": int(g["node_type"].numel())}


if __name__ == "__main__":
    sys.exit(main())
