#!/usr/bin/env python3
"""Fetch the public archives behind the four benchmark cohorts.

    python download.py --dataset D1 --out ./data
    python download.py --dataset all --out ./data --dry-run

Accessions and endpoints are exactly those listed in the manuscript's Data
Availability Statement. The script resolves each study accession to its run or
assembly list through the public ENA / NCBI / gcMeta endpoints and writes the
manifest to <out>/<dataset>/manifest.tsv; it does not bundle any sequence data
and it does not guess an accession that an archive does not return.

D1  UHGG Human Gut Resistome v2.0   ENA study ERP116715
D2  Global Urban Sewage Surveillance ENA study ERP015409, BioProject PRJEB13831
D3  Indian Metropolitan Wastewater   NCBI BioProject PRJNA743269, SRA SRP336045
D4  gcMeta Cross-Ecosystem           https://gcmeta.nmdc.cn
"""
import argparse, json, sys, urllib.error, urllib.parse, urllib.request
from pathlib import Path

ENA_PORTAL = "https://www.ebi.ac.uk/ena/portal/api/filereport"
NCBI_ESEARCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"

DATASETS = {
    "D1": {"name": "UHGG Human Gut Resistome v2.0",
           "ena_studies": ["ERP116715"],
           "bioprojects": [],
           "http_mirror": "https://ftp.ebi.ac.uk/pub/databases/metagenomics/"
                          "mgnify_genomes/human-gut/v2.0/",
           "catalogue": "https://www.ebi.ac.uk/metagenomics/genome-catalogues/"
                        "human-gut-v2-0-2",
           "mags_reported": 204938, "mags_after_mash": 203091},
    "D2": {"name": "Global Urban Sewage Surveillance",
           "ena_studies": ["ERP015409"],
           "bioprojects": ["PRJEB13831"],
           "http_mirror": None, "catalogue": None,
           "mags_reported": 1243800, "mags_after_mash": 1240388},
    "D3": {"name": "Indian Metropolitan Wastewater",
           "ena_studies": ["SRP336045"],
           "bioprojects": ["PRJNA743269"],
           "http_mirror": None, "catalogue": None,
           "mags_reported": 69248, "mags_after_mash": 69050},
    "D4": {"name": "gcMeta Cross-Ecosystem",
           "ena_studies": [], "bioprojects": [],
           "http_mirror": "https://gcmeta.nmdc.cn",
           "catalogue": "https://gcmeta.nmdc.cn",
           "mags_reported": 387451, "mags_after_mash": 385348,
           "note": "gcMeta requires its own catalogue query; see "
                   "https://gcmeta.nmdc.cn and DOI 10.1093/nar/gkaf1115. "
                   "Supply the exported accession list with --accession-list."},
}

FIELDS = ("run_accession,sample_accession,study_accession,experiment_accession,"
          "library_strategy,read_count,base_count,fastq_ftp")


def fetch(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "PanMetaGraph/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def ena_report(study):
    q = urllib.parse.urlencode({"accession": study, "result": "read_run",
                                "fields": FIELDS, "format": "tsv",
                                "limit": "0"})
    return fetch(f"{ENA_PORTAL}?{q}")


def ncbi_count(bioproject):
    q = urllib.parse.urlencode({"db": "sra", "term": f"{bioproject}[BioProject]",
                                "retmode": "json", "retmax": "0"})
    return json.loads(fetch(f"{NCBI_ESEARCH}?{q}"))["esearchresult"]["count"]


def one(key, out, dry, accession_list=None):
    spec = DATASETS[key]
    d = Path(out) / key
    d.mkdir(parents=True, exist_ok=True)
    (d / "dataset.json").write_text(json.dumps({"dataset": key, **spec}, indent=2))
    print(f"\n{key}  {spec['name']}")
    for field, label in (("ena_studies", "ENA study"), ("bioprojects", "BioProject")):
        for acc in spec[field]:
            print(f"  {label:<11} {acc}")
    if spec.get("note"):
        print(f"  note        {spec['note']}")
    if dry:
        return
    rows = []
    for study in spec["ena_studies"]:
        try:
            tsv = ena_report(study)
        except (urllib.error.URLError, urllib.error.HTTPError) as e:
            print(f"  ! ENA request for {study} failed: {e}. "
                  f"Retry, or download the report manually from "
                  f"https://www.ebi.ac.uk/ena/browser/view/{study}")
            continue
        lines = [l for l in tsv.splitlines() if l.strip()]
        if len(lines) <= 1:
            print(f"  ! ENA returned no runs for {study}")
            continue
        header, body = lines[0], lines[1:]
        rows.append((header, body))
        print(f"  {study}: {len(body)} runs")
    if accession_list:
        extra = [l.strip() for l in Path(accession_list).read_text().splitlines() if l.strip()]
        print(f"  {accession_list}: {len(extra)} accessions supplied")
        (d / "supplied_accessions.txt").write_text("\n".join(extra) + "\n")
    for bp in spec["bioprojects"]:
        try:
            print(f"  {bp}: {ncbi_count(bp)} SRA records")
        except Exception as e:
            print(f"  ! NCBI request for {bp} failed: {e}")
    if rows:
        header = rows[0][0]
        body = [l for _, b in rows for l in b]
        (d / "manifest.tsv").write_text("\n".join([header] + body) + "\n")
        print(f"  wrote {d/'manifest.tsv'} ({len(body)} runs)")
        if len(body) == 0:
            print("  ! manifest is empty; do not proceed to build_graph.py")
    print(f"  MAGs used in the paper: {spec['mags_reported']:,} "
          f"({spec['mags_after_mash']:,} after Mash filtering)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="all", choices=["all", *DATASETS])
    ap.add_argument("--out", default="./data")
    ap.add_argument("--dry-run", action="store_true",
                    help="print the accessions without contacting any archive")
    ap.add_argument("--accession-list",
                    help="file of accessions exported from gcMeta (D4)")
    a = ap.parse_args()
    keys = list(DATASETS) if a.dataset == "all" else [a.dataset]
    for k in keys:
        one(k, a.out, a.dry_run, a.accession_list)
    print("\nNext: python build_graph.py --dataset <D1|D2|D3|D4> --root "
          f"{a.out}   (see README, 'Building a cohort graph')")


if __name__ == "__main__":
    sys.exit(main())
