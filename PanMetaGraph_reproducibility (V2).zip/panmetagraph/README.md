# PanMetaGraph

Reproducibility package for *PanMetaGraph: Graph Transformers for Metagenomic
AMR Discovery*.

The package contains the model implementation, the exact hyperparameter
configurations behind every reported experiment, the training and evaluation
pipeline, the statistical analysis, and a verifier that checks the values
shipped here against the numbers printed in the paper.

---

## Quick start: verify the package against the manuscript

No data, no GPU and no PyTorch required; takes a few seconds.

```bash
pip install numpy scipy PyYAML
python verify_against_manuscript.py     # 204 consistency checks
python generate_expected.py --out tables
python test.py                          # unit tests
```

`verify_against_manuscript.py` confirms, among other things, that every Table 7
delta equals the variant minus the full model on the variant's own cohort, that
every Table 8 difference equals the corresponding Table 6 cells, that each
Table 8 confidence interval reproduces as a Student-t interval from the
per-seed standard deviations in that table, and that each ablation config
targets the cohort Table 7 assigns to it, and that Table 9's total training
time equals max epochs x 10 seeds x minutes per epoch. It exits non-zero if any check fails.

`python test.py` runs the unit tests. The model tests require PyTorch and are
reported as skipped when it is not installed; the metric, statistics,
configuration and consistency tests run without it.

## Repository layout

```
manuscript_values.py          Tables 6-10 transcribed verbatim; the single
                              source of truth for every other script
verify_against_manuscript.py  package <-> manuscript consistency checks
generate_expected.py          writes tables/expected_table{6,7,8,9,10}.csv
evaluate_all.py               aggregates runs; paired t-tests + Holm correction
make_figures.py               regenerates Figures 5 and 6
train.py                      one cohort, one seed
build_graph.py                raw archives -> cohort graph tensor
download.py                   resolves the public accessions to a manifest
run_ablation.sh               the Table 7 grid
test.py                       unit tests
configs/default.yaml          the Table 5 hyperparameters
configs/ablations/            one config per Table 7 row, named by variant
src/model.py                  Eqs. (8)-(19)
src/data.py                   graph loading and splits
src/metrics.py                AUROC, macro-F1, MRR, P@50, PR-AUC, MCC
src/stats.py                  paired t-test, Student-t CI, BCa bootstrap, Holm
src/config.py                 config loading with `base:` inheritance
scripts/set_seed.py           deterministic seeding
environment.lock              exact versions, hardware and determinism settings
```

## Model

`src/model.py` implements the architecture described in Section 5:

| Component | Equations | Where |
|---|---|---|
| Random-walk positional encoding (k = 20) | (8)-(9) | `RandomWalkPE` |
| Per-relation Q/K/V with per-relation softmax | (10)-(14) | `RelationAttention` |
| Learnable relation weights β_r | (15) | `RelationAttention.beta` |
| Pre-norm transformer block | (16) | `EncoderLayer` |
| Transfer-probability refinement | (17)-(18) | `TransferHead` |
| L = L_cls + µ·L_tr, µ = 0.1 | (19) | `PanMetaGraph.loss` |

Four node types (contig, gene cluster, MGE, sample) and four relation types
(reference alignment, pangenome adjacency, MGE link, ecological co-occurrence).
The task is 541-class node classification over ARG families.

## Reproducing the results

### 1. Data

```bash
python download.py --dataset all --out ./data --dry-run   # show accessions
python download.py --dataset D1  --out ./data             # resolve a manifest
```

| Cohort | Source | Accession | MAGs used |
|---|---|---|---|
| D1 | UHGG Human Gut Resistome v2.0 | ENA `ERP116715` | 204,938 (203,091 after Mash) |
| D2 | Global Urban Sewage Surveillance | ENA `ERP015409`, BioProject `PRJEB13831` | 1,243,800 (1,240,388) |
| D3 | Indian Metropolitan Wastewater | BioProject `PRJNA743269`, SRA `SRP336045` | 69,248 (69,050) |
| D4 | gcMeta Cross-Ecosystem | <https://gcmeta.nmdc.cn> | 387,451 (385,348) |

D4 is distributed through the gcMeta catalogue rather than a single accession;
export its accession list and pass it with `--accession-list`.

### 2. Building a cohort graph

```bash
python build_graph.py --list-stages
python build_graph.py --dataset D4 --root ./data \
       --mags /path/to/mags --arg-db /path/to/arg_reference.dmnd --threads 32
```

Stages are resumable and each writes its raw output under
`data/<cohort>/work/`. The script checks for the external binaries up front and
stops with the list of what is missing rather than producing a partial graph.

#### External tools

CheckM 1.1.3 (D1-D3) and 1.2.2 (D4), MetaBAT2 2.15, Mash 2.3, PGGB 0.5.4,
DIAMOND 2.1.8, HMMER 3.3.2. Exact versions are in `environment.lock`.

### 3. Training

```bash
python train.py --config configs/default.yaml --dataset D4 --seed 0
```

Writes `results/full_D4_seed0/{best.pt,metrics.json,log.jsonl}`. The paper
reports means over the ten seeds `{0,...,9}`.

### 4. The ablation grid (Table 7)

```bash
bash run_ablation.sh                        # 13 variants x 10 seeds
bash run_ablation.sh --variants full i ii --seeds 0 1 2
bash run_ablation.sh --dry-run              # print the commands only
```

Each variant runs on the cohort its own config names: D1 for (x), D3 for (xi),
D4 for the rest, exactly as Table 7 reports them.

### 5. Aggregation and statistics

```bash
python evaluate_all.py --results results --out tables --stats
```

Writes `tables/observed_vs_manuscript.csv` with the mean, SD, the manuscript
value and the signed difference for every cell, and
`tables/statistical_tests.csv` with the paired t-tests and Holm-corrected
p-values. Cells reproduced from fewer than ten seeds, and cells differing from
the reported value by more than the tolerance, are listed explicitly rather
than absorbed.

### 6. Figures

```bash
python make_figures.py --out figures --dpi 600
```

## Hyperparameters (Table 5)

Layers 4 · heads 8 · d 256 · FFN 1024 · walk length 20 · dropout 0.1 ·
λ 1 × 10⁻⁴ · µ 0.1 · AdamW · lr 3 × 10⁻⁴ · 1,000 warmup steps · cosine
schedule · batch 512 nodes · max 100 epochs · patience 15 · 70/10/20 split ·
edge feature dimension 64.

Ablation configs inherit all of these through `base: ../default.yaml` and
override only what the variant changes, so a hyperparameter can be altered in
one place.

## Statistical protocol

Ten independent runs per cell with seeds `{0,...,9}`. The statistical unit is
the per-seed metric. Paired two-sided t-tests compare matched seeds against
AMR-GNN, the one baseline retrained under identical conditions; the
Holm-Bonferroni correction is applied over the family of twelve tests (three
metrics × four cohorts). The 95% confidence intervals in Table 8 are Student-t
intervals on the mean paired difference computed from the per-seed standard
deviations over n = 10. `src/stats.py` also provides the BCa bootstrap
interval for use when the per-seed values themselves are to hand, in which case
the paired interval is the tighter and preferable one.

Differences against the other five learned baselines are descriptive: those
methods were not retrained with matched seeds, so no paired test is reported
for them.

## Scale

The largest graph trained and evaluated here is D4: 3,187,409 nodes and
19,712,883 edges, on four A100 80 GB GPUs with PyTorch Geometric's
`NeighborLoader` at a fan-out of 15 and a batch of 512 nodes. Results in the
paper pertain to N ≤ 3.2 × 10⁶ nodes; larger regimes shown in the scalability
figure are synthetic extrapolations and are labelled as such.

## Licence

MIT. See `LICENSE`.
