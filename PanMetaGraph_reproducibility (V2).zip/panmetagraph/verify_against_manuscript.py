#!/usr/bin/env python3
"""Check that the values shipped in this package are internally consistent with
the manuscript tables they were transcribed from.

    python verify_against_manuscript.py

Runs without torch, a GPU or any downloaded data, so a reviewer can confirm the
package-manuscript correspondence in seconds. Checks:

  1. Table 6 is complete: 7 methods x 4 cohorts x 5 metrics, with the cohort's
     own third primary metric (MRR for D1/D4, P@50 for D2/D3).
  2. PanMetaGraph is the best method on all 12 cohort-primary-metric cells.
  3. Table 7 full-model AUROC and Macro-F1 equal the Table 6 D4 PanMetaGraph row.
  4. Every Table 7 delta equals variant minus full model on the variant's own
     dataset (D1 for (x), D3 for (xi), D4 otherwise).
  5. Table 8 raw differences equal PanMetaGraph minus AMR-GNN from Table 6.
  6. Table 8 printed CIs equal Student-t intervals recomputed from the per-seed
     SDs in the same table, n = 10, as stated in its caption.
  7. All Table 8 CIs exclude zero, consistent with the reported p < 0.001.
  8. The Holm family size (12) equals the number of Table 8 rows.
  9. Per-cohort post-Mash MAG counts sum to the total stated in the Abstract.
 10. Each ablation config exists, targets the right cohort and carries the
     intended override.
 11. Table 10 orders PanMetaGraph last on parameters and cost, as the text says.
 12. Table 9's total training time equals max epochs x 10 seeds x minutes per
     epoch, and its D4 per-epoch time agrees with Table 10's PanMetaGraph row.

Exit status is non-zero if any check fails.
"""
import sys
from pathlib import Path

from manuscript_values import (TABLE6, TABLE7, TABLE8, TABLE9, TABLE10,
                               EPOCHS_MAX, DATASETS, THIRD_METRIC, SECONDARY,
                               MAGS_MASH)
from src.stats import ci_from_sds
from src.config import load_config

ABSTRACT_TOTAL_MAGS = 1_897_877      # "1,897,877 quality-filtered MAGs"
HOLM_FAMILY = 12
OVERRIDE = {"i": ("use_rwpe", False), "ii": ("drop_relations", ["mge_link"]),
            "iii": ("drop_relations", ["eco_cooc"]), "iv": ("encoder", "gcn"),
            "v": ("ref_alignment", "linear"), "vi": ("use_transfer_refinement", False),
            "vii": ("positional_encoding", "sinusoidal"), "viii": ("encoder", "gat"),
            "ix": ("use_edge_weights", False), "x": ("drop_relations", ["mge_link"]),
            "xi": ("drop_relations", ["eco_cooc"]),
            "xii": ("drop_relations", ["mge_link", "eco_cooc"])}

ok, bad = [], []


def chk(cond, msg):
    (ok if cond else bad).append(msg)


# 1 - completeness
for meth, per in TABLE6.items():
    for ds in DATASETS:
        want = {"auroc", "macro_f1", THIRD_METRIC[ds], *SECONDARY}
        chk(set(per[ds]) == want, f"Table 6 {meth}/{ds} reports {sorted(want)}")
chk(len(TABLE6) == 7, "Table 6 lists 7 methods")

# 2 - PanMetaGraph best on every primary cell
for ds in DATASETS:
    for met in ("auroc", "macro_f1", THIRD_METRIC[ds]):
        ours = TABLE6["PanMetaGraph"][ds][met][0]
        others = [v[ds][met][0] for k, v in TABLE6.items() if k != "PanMetaGraph"]
        chk(ours > max(others), f"PanMetaGraph best on {ds}/{met} "
                                f"({ours:.3f} vs {max(others):.3f})")

# 3 - Table 7 full row vs Table 6
d4 = TABLE6["PanMetaGraph"]["D4"]
chk(abs(TABLE7["full"][2] - d4["auroc"][0]) < 1e-9,
    "Table 7 full AUROC matches Table 6 D4")
chk(abs(TABLE7["full"][4] - d4["macro_f1"][0]) < 1e-9,
    "Table 7 full Macro-F1 matches Table 6 D4")

# 4 - deltas
FULL = {"D4": (TABLE7["full"][2], TABLE7["full"][4], TABLE7["full"][6]),
        "D1": (TABLE6["PanMetaGraph"]["D1"]["auroc"][0],
               TABLE6["PanMetaGraph"]["D1"]["macro_f1"][0], None),
        "D3": (TABLE6["PanMetaGraph"]["D3"]["auroc"][0],
               TABLE6["PanMetaGraph"]["D3"]["macro_f1"][0], None)}
for vid, (label, ds, au, dau, f1, df1, p50, dp50) in TABLE7.items():
    if vid == "full":
        continue
    fa, ff, fp = FULL[ds]
    chk(abs((au - fa) - dau) < 5e-4, f"Table 7 ({vid}) AUROC delta {dau:+.3f}")
    chk(abs((f1 - ff) - df1) < 5e-4, f"Table 7 ({vid}) F1 delta {df1:+.3f}")
    if p50 is not None:
        chk(abs((p50 - fp) - dp50) < 5e-4, f"Table 7 ({vid}) P@50 delta {dp50:+.3f}")

# 5-7 - Table 8
chk(len(TABLE8) == HOLM_FAMILY, f"Table 8 has {HOLM_FAMILY} rows (Holm family size)")
for ds, met, (m1, s1), (m2, s2), diff, lo, hi in TABLE8:
    t6a, t6b = TABLE6["PanMetaGraph"][ds][met], TABLE6["AMR-GNN"][ds][met]
    chk((m1, s1) == t6a and (m2, s2) == t6b,
        f"Table 8 {ds}/{met} arms match Table 6")
    chk(abs((m1 - m2) - diff) < 5e-4, f"Table 8 {ds}/{met} diff {diff:+.3f}")
    rlo, rhi = ci_from_sds(m1, s1, m2, s2, n=10)
    chk(abs(round(rlo, 3) - lo) < 1e-9 and abs(round(rhi, 3) - hi) < 1e-9,
        f"Table 8 {ds}/{met} CI [{lo:.3f}, {hi:.3f}] reproduces from the SDs")
    chk(lo > 0, f"Table 8 {ds}/{met} CI excludes zero")

# 9 - MAG counts
tot = sum(MAGS_MASH.values())
chk(tot == ABSTRACT_TOTAL_MAGS,
    f"post-Mash MAGs sum to {tot:,} = Abstract total")

# 10 - ablation configs
root = Path(__file__).resolve().parent
for vid, (label, ds, *_rest) in TABLE7.items():
    f = root / "configs" / "ablations" / f"ablation_{vid}.yaml"
    chk(f.exists(), f"configs/ablations/ablation_{vid}.yaml exists")
    if not f.exists():
        continue
    cfg = load_config(f)
    chk(cfg["dataset"] == ds, f"ablation_{vid} targets {ds}")
    chk(cfg["label"] == label, f"ablation_{vid} label matches Table 7")
    if vid in OVERRIDE:
        k, v = OVERRIDE[vid]
        chk(cfg["model"].get(k) == v, f"ablation_{vid} sets {k}={v}")
    chk(cfg["model"]["n_layers"] == 4 and cfg["model"]["d_model"] == 256
        and cfg["model"]["rw_steps"] == 20 and cfg["optim"]["lr"] == 3e-4
        and cfg["optim"]["weight_decay"] == 1e-4
        and cfg["optim"]["batch_size"] == 512,
        f"ablation_{vid} inherits the Table 5 hyperparameters")

# 11 - Table 10 ordering
par = TABLE10["PanMetaGraph"]
chk(all(par[0] >= v[0] for v in TABLE10.values()),
    "Table 10: PanMetaGraph has the largest parameter count")
chk(all(par[1] >= v[1] for v in TABLE10.values()),
    "Table 10: PanMetaGraph has the longest per-epoch training time")
chk(all(par[2] >= v[2] for v in TABLE10.values()),
    "Table 10: PanMetaGraph has the highest per-sample inference latency")

# 12 - Table 9 internal arithmetic and its agreement with Table 10
for ds, (n, e, nt, et, tr, gb, tot, inf) in TABLE9.items():
    chk(abs(tr * EPOCHS_MAX * 10 / 60 - tot) < 0.05,
        f"Table 9 {ds}: {tot:.1f} h = {EPOCHS_MAX} epochs x 10 seeds x {tr:.1f} min")
    chk(e > n and nt == 4 and et == 4,
        f"Table 9 {ds}: 4 node types, 4 relation types, more edges than nodes")
chk(abs(TABLE9["D4"][4] - TABLE10["PanMetaGraph"][1]) < 1e-9,
    "Table 9 D4 per-epoch time matches Table 10's PanMetaGraph row")
chk(all(TABLE9[d][7] == TABLE10["PanMetaGraph"][2] for d in DATASETS),
    "Table 9 inference latency matches Table 10's PanMetaGraph row")

for m in ok:
    print(f"  PASS  {m}")
for m in bad:
    print(f"  FAIL  {m}")
print(f"\n{len(ok)} passed, {len(bad)} failed")
sys.exit(1 if bad else 0)
