#!/usr/bin/env python3
"""Emit the manuscript's reported values as machine-readable reference files.

    python generate_expected.py --out tables/

Writes tables/expected_table6.csv, expected_table7.csv, expected_table8.csv,
expected_table9.csv and expected_values.json. Every number comes from
manuscript_values.py, which is a verbatim transcription of Tables 6-9; nothing
is recomputed except the delta and CI columns, which are derived from those same
numbers and are checked against the printed values by
verify_against_manuscript.py.

These files are the reference that evaluate_all.py compares fresh runs against.
Requires only the standard library.
"""
import argparse, csv, json
from pathlib import Path

from manuscript_values import (TABLE6, TABLE7, TABLE8, TABLE9, TABLE10,
                               EPOCHS_MAX, DATASETS, THIRD_METRIC, PRIMARY,
                               SECONDARY)
from src.metrics import METRIC_LABELS
from src.stats import ci_from_sds

ORDER = ["DeepARG", "TransAMR", "AMR-GNN", "HetGAT-TB", "MDGNN",
         "MetaTransformer", "PanMetaGraph"]


def table6_rows():
    for meth in ORDER:
        row = {"method": meth}
        for ds in DATASETS:
            cell = TABLE6[meth][ds]
            for key in ["auroc", "macro_f1", THIRD_METRIC[ds]] + SECONDARY:
                m, s = cell[key]
                row[f"{ds}_{METRIC_LABELS[key]}"] = f"{m:.3f} ± {s:.3f}"
        yield row


def table7_rows():
    for vid, (label, ds, au, dau, f1, df1, p50, dp50) in TABLE7.items():
        yield {"variant": vid, "label": label, "dataset": ds,
               "AUROC": f"{au:.3f}",
               "AUROC_delta": "" if dau is None else f"{dau:+.3f}",
               "Macro-F1": f"{f1:.3f}",
               "F1_delta": "" if df1 is None else f"{df1:+.3f}",
               "P@50": "" if p50 is None else f"{p50:.3f}",
               "P50_delta": "" if dp50 is None else f"{dp50:+.3f}"}


def table8_rows():
    for ds, met, (m1, s1), (m2, s2), diff, lo, hi in TABLE8:
        dlo, dhi = ci_from_sds(m1, s1, m2, s2, n=10)
        yield {"dataset": ds, "metric": METRIC_LABELS[met],
               "PanMetaGraph": f"{m1:.3f} ± {s1:.3f}",
               "AMR-GNN": f"{m2:.3f} ± {s2:.3f}",
               "raw_diff": f"{diff:+.3f}",
               "ci_95": f"[{lo:.3f}, {hi:.3f}]",
               "ci_95_recomputed": f"[{dlo:.3f}, {dhi:.3f}]"}


def table9_rows():
    for ds, (n, e, nt, et, tr, gb, tot, inf) in TABLE9.items():
        yield {"dataset": ds, "nodes": n, "edges": e, "node_types": nt,
               "edge_types": et, "train_min_per_epoch": f"{tr:.1f}",
               "peak_gpu_gb_4x_a100": f"{gb:.1f}",
               "total_train_hrs_10_seeds": f"{tot:.1f}",
               "inference_us_per_sample": inf}


def table10_rows():
    for meth, (par, tr, inf) in TABLE10.items():
        yield {"method": meth, "params_M": f"{par:.1f}",
               "train_min_per_epoch": f"{tr:.1f}", "inference_us_per_sample": inf}


def write_csv(path, rows):
    rows = list(rows)
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return len(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="tables")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    n6 = write_csv(out / "expected_table6.csv", table6_rows())
    n7 = write_csv(out / "expected_table7.csv", table7_rows())
    n8 = write_csv(out / "expected_table8.csv", table8_rows())
    n9 = write_csv(out / "expected_table9.csv", table9_rows())
    n10 = write_csv(out / "expected_table10.csv", table10_rows())
    (out / "expected_values.json").write_text(json.dumps(
        {"table6": TABLE6, "table7": TABLE7,
         "table8": [{"dataset": d, "metric": m, "panmetagraph": a1,
                     "amr_gnn": a2, "diff": df, "ci": [lo, hi]}
                    for d, m, a1, a2, df, lo, hi in TABLE8],
         "table9": TABLE9, "table10": TABLE10,
         "epochs_max": EPOCHS_MAX,
         "third_metric": THIRD_METRIC,
         "primary": PRIMARY, "secondary": SECONDARY}, indent=2))
    print(f"wrote {out}/expected_table6.csv ({n6} methods), "
          f"expected_table7.csv ({n7} variants), expected_table8.csv ({n8} tests), "
          f"expected_table9.csv ({n9} cohorts), "
          f"expected_table10.csv ({n10} methods), expected_values.json")


if __name__ == "__main__":
    main()
