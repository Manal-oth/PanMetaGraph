#!/usr/bin/env python3
"""Train PanMetaGraph on one cohort with one seed.

    python train.py --config configs/default.yaml --dataset D4 --seed 0
    python train.py --config configs/ablations/ablation_ii.yaml --seed 3

Writes <out_dir>/<variant>_<dataset>_seed<seed>/{best.pt,metrics.json,log.jsonl}.
Requires torch (and, for the full sampled pipeline, torch_geometric); see
requirements.txt. Nothing here fabricates data: if the cohort graph has not been
built, the run stops with the command needed to build it.
"""
import argparse, json, math, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from scripts.set_seed import set_seed
from src.config import load_config, parse_set
from src.data import load_graph, split_view, node_batches
from src.metrics import compute_all
from manuscript_values import THIRD_METRIC


def build_model(cfg, in_dims):
    import torch
    from src.model import PanMetaGraph
    m = cfg["model"]
    if m.get("encoder", "transformer") != "transformer":
        print(f"[info] encoder={m['encoder']} (ablation variant {cfg.get('variant')})")
    net = PanMetaGraph(in_dims, d_model=m["d_model"], n_heads=m["n_heads"],
                       n_layers=m["n_layers"], n_classes=m["n_classes"],
                       n_relations=m["n_relations"], rw_steps=m["rw_steps"],
                       ff_mult=m["ff_mult"], dropout=m["dropout"],
                       mu=m.get("mu", 0.1))
    if m.get("learn_beta_r", True) is False:
        for layer in net.layers:
            layer.attn.beta.requires_grad_(False)
    if m.get("use_transfer_refinement", True) is False:
        for p in net.transfer.parameters():
            p.requires_grad_(False)
    return net


def lr_at(step, cfg):
    o = cfg["optim"]
    w = max(o["warmup_steps"], 1)
    if step < w:
        return o["lr"] * step / w
    total = max(o["total_steps"] - w, 1)
    prog = min((step - w) / total, 1.0)
    return 0.5 * o["lr"] * (1 + math.cos(math.pi * prog))


def evaluate(net, batch, which, third, n_classes):
    import torch
    net.eval()
    v = split_view(batch, which)
    with torch.no_grad():
        out = net({**v, "pair_index": None})
        probs = torch.softmax(out["logits"][v["label_index"]], dim=-1).cpu().numpy()
    return compute_all(v["y"].cpu().numpy(), probs, third, n_classes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--dataset")
    ap.add_argument("--seed", type=int)
    ap.add_argument("--data-root")
    ap.add_argument("--out-dir")
    ap.add_argument("--device", default=None)
    ap.add_argument("--set", nargs="*", default=[])
    a = ap.parse_args()

    cfg = load_config(a.config, parse_set(a.set))
    if a.dataset:   cfg["dataset"] = a.dataset
    if a.seed is not None: cfg["seed"] = a.seed
    if a.data_root: cfg["data_root"] = a.data_root
    if a.out_dir:   cfg["out_dir"] = a.out_dir

    import torch
    set_seed(cfg["seed"])
    dev = a.device or ("cuda" if torch.cuda.is_available() else "cpu")
    ds = cfg["dataset"]
    m, o = cfg["model"], cfg["optim"]

    batch = load_graph(cfg["data_root"], ds, relations=m.get("relations"),
                       drop_relations=m.get("drop_relations", ()),
                       use_rwpe=m.get("use_rwpe", True),
                       use_edge_weights=m.get("use_edge_weights", True),
                       device=dev)
    in_dims = {k: v.size(1) for k, v in batch["x_dict"].items()}
    net = build_model(cfg, in_dims).to(dev)
    n_train = len(batch["split"]["train"])
    steps_per_epoch = max(1, math.ceil(n_train / o["batch_size"]))
    o["total_steps"] = steps_per_epoch * o["max_epochs"]

    params = [p for p in net.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=o["lr"], weight_decay=o["weight_decay"])
    third = THIRD_METRIC[ds]
    tag = f"{cfg.get('variant', 'full')}_{ds}_seed{cfg['seed']}"
    run = Path(cfg["out_dir"]) / tag
    run.mkdir(parents=True, exist_ok=True)
    log = (run / "log.jsonl").open("w")

    gen = torch.Generator().manual_seed(cfg["seed"])
    best, best_epoch, step = -1.0, -1, 0
    train = split_view(batch, "train")
    t0 = time.time()
    for epoch in range(1, o["max_epochs"] + 1):
        net.train()
        for sel in node_batches(len(train["label_index"]), o["batch_size"], gen):
            step += 1
            for g in opt.param_groups:
                g["lr"] = lr_at(step, cfg)
            sub = {**train, "label_index": train["label_index"][sel],
                   "y": train["y"][sel]}
            out = net(sub)
            loss, parts = net.loss(out, sub)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, o["grad_clip"])
            opt.step()
        val = evaluate(net, batch, "val", third, m["n_classes"])
        log.write(json.dumps({"epoch": epoch, "step": step, **parts,
                              "val": val}) + "\n"); log.flush()
        score = val["auroc"]
        if score > best:
            best, best_epoch = score, epoch
            torch.save({"model": net.state_dict(), "config": cfg,
                        "epoch": epoch, "val": val}, run / "best.pt")
        elif epoch - best_epoch >= o["patience"]:
            print(f"early stop at epoch {epoch} (best {best_epoch})")
            break

    ck = torch.load(run / "best.pt", map_location=dev, weights_only=False)
    net.load_state_dict(ck["model"])
    test = evaluate(net, batch, "test", third, m["n_classes"])
    res = {"variant": cfg.get("variant", "full"), "dataset": ds,
           "seed": cfg["seed"], "best_epoch": best_epoch,
           "minutes": round((time.time() - t0) / 60, 2),
           "val": ck["val"], "test": test}
    (run / "metrics.json").write_text(json.dumps(res, indent=2))
    log.close()
    print(json.dumps(res["test"], indent=2))
    return res


if __name__ == "__main__":
    main()
