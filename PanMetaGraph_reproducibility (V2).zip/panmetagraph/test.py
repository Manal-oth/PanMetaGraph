#!/usr/bin/env python3
"""Self-tests for the package. Run with:

    python test.py            # or: python -m pytest test.py -q

The metric and statistics tests use inputs whose answers can be worked out by
hand, so a wrong implementation fails rather than merely changing a number. The
model test exercises a real forward and backward pass on a small synthetic
graph; it is skipped when torch is not installed. Nothing here needs the
cohort data or a GPU.
"""
import math, subprocess, sys, unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from manuscript_values import TABLE6, TABLE7, TABLE8, DATASETS, THIRD_METRIC
from src import metrics as M
from src import stats as S
from src.config import load_config, parse_set


class TestMetrics(unittest.TestCase):
    def test_auroc_perfect_and_inverted(self):
        y = np.array([0, 0, 1, 1])
        perfect = np.array([[.9, .1], [.8, .2], [.2, .8], [.1, .9]])
        self.assertAlmostEqual(M.auroc_macro(y, perfect), 1.0, places=9)
        self.assertAlmostEqual(M.auroc_macro(y, perfect[:, ::-1]), 0.0, places=9)

    def test_auroc_ties_give_half(self):
        y = np.array([0, 1])
        p = np.array([[.5, .5], [.5, .5]])
        self.assertAlmostEqual(M.auroc_macro(y, p), 0.5, places=9)

    def test_macro_f1_hand_computed(self):
        # class 0: tp=1 fp=1 fn=0 -> P=.5 R=1 F1=2/3; class 1: tp=1 fp=0 fn=1 -> F1=2/3
        y = np.array([0, 1, 1]); yp = np.array([0, 0, 1])
        self.assertAlmostEqual(M.macro_f1(y, yp, 2), 2 / 3, places=9)

    def test_mrr_ranks(self):
        y = np.array([0, 1])
        p = np.array([[.2, .8], [.2, .8]])   # true class ranked 2nd, then 1st
        self.assertAlmostEqual(M.mrr(y, p), (0.5 + 1.0) / 2, places=9)

    def test_precision_at_k_is_macro_averaged(self):
        # both classes rank their own positives first -> each 1.0, macro 1.0
        y = np.array([1, 1, 0, 0])
        p = np.zeros((4, 2)); p[:, 1] = [.9, .8, .7, .6]; p[:, 0] = [.1, .2, .4, .3]
        self.assertAlmostEqual(M.precision_at_k(y, p, 2), 1.0, places=9)
        # class 1 ranks one positive and one negative in its top-2 -> 0.5, and
        # class 0 likewise -> macro 0.5
        q = np.zeros((4, 2)); q[:, 1] = [.9, .1, .8, .2]; q[:, 0] = [.2, .8, .1, .9]
        self.assertAlmostEqual(M.precision_at_k(y, q, 2), 0.5, places=9)

    def test_mcc_perfect_and_zero(self):
        y = np.array([0, 0, 1, 1])
        self.assertAlmostEqual(M.mcc_multiclass(y, y, 2), 1.0, places=9)
        self.assertAlmostEqual(M.mcc_multiclass(y, 1 - y, 2), -1.0, places=9)

    def test_average_precision_hand_computed(self):
        y = np.array([1, 0, 1, 0]); s = np.array([.9, .8, .7, .6])
        self.assertAlmostEqual(M.average_precision(y, s), (1.0 + 2 / 3) / 2, places=9)

    def test_compute_all_uses_cohort_third_metric(self):
        y = np.random.default_rng(0).integers(0, 3, 40)
        p = np.random.default_rng(1).random((40, 3)); p /= p.sum(1, keepdims=True)
        self.assertIn("mrr", M.compute_all(y, p, "mrr", 3))
        self.assertIn("p_at_50", M.compute_all(y, p, "p_at_50", 3))


class TestStats(unittest.TestCase):
    def test_t_quantile_matches_known_value(self):
        self.assertAlmostEqual(S._t_ppf(0.975, 9), 2.262157, places=5)

    def test_paired_t_on_constant_difference(self):
        a = np.arange(10, dtype=float) + 1.0
        diff, t, p = S.paired_t_test(a, a - 0.5)
        self.assertAlmostEqual(diff, 0.5, places=12)
        self.assertEqual(t, 0.0)          # zero variance of the differences

    def test_paired_ci_brackets_mean(self):
        rng = np.random.default_rng(0)
        a, b = rng.normal(0.96, 0.003, 10), rng.normal(0.91, 0.005, 10)
        lo, hi = S.paired_t_ci(a, b)
        self.assertLess(lo, (a - b).mean())
        self.assertGreater(hi, (a - b).mean())

    def test_ci_from_sds_matches_closed_form(self):
        lo, hi = S.ci_from_sds(0.961, 0.003, 0.914, 0.005, n=10)
        hw = 2.262157 * math.sqrt(0.003 ** 2 + 0.005 ** 2) / math.sqrt(10)
        self.assertAlmostEqual(hi - lo, 2 * hw, places=6)
        self.assertAlmostEqual((lo + hi) / 2, 0.047, places=9)

    def test_holm_is_monotone_and_bounded(self):
        adj, rej = S.holm_bonferroni([0.001, 0.01, 0.04, 0.5])
        self.assertEqual(adj, sorted(adj))
        self.assertTrue(all(0 <= x <= 1 for x in adj))
        self.assertTrue(rej[0])

    def test_holm_single_test_is_unchanged(self):
        adj, _ = S.holm_bonferroni([0.03])
        self.assertAlmostEqual(adj[0], 0.03, places=12)

    def test_bca_ci_brackets_the_estimate(self):
        rng = np.random.default_rng(3)
        a, b = rng.normal(0.95, 0.004, 10), rng.normal(0.90, 0.006, 10)
        lo, hi = S.bca_bootstrap_ci(a, b, n_boot=400, seed=1)
        self.assertLess(lo, (a - b).mean())
        self.assertGreater(hi, (a - b).mean())


class TestConfigs(unittest.TestCase):
    def test_default_matches_table5(self):
        c = load_config(ROOT / "configs/default.yaml")
        self.assertEqual(c["model"]["n_layers"], 4)
        self.assertEqual(c["model"]["n_heads"], 8)
        self.assertEqual(c["model"]["d_model"], 256)
        self.assertEqual(c["model"]["d_model"] * c["model"]["ff_mult"], 1024)
        self.assertEqual(c["model"]["rw_steps"], 20)
        self.assertEqual(c["model"]["dropout"], 0.1)
        self.assertEqual(c["model"]["mu"], 0.1)
        self.assertEqual(c["model"]["n_classes"], 541)
        self.assertEqual(c["optim"]["lr"], 3e-4)
        self.assertEqual(c["optim"]["weight_decay"], 1e-4)
        self.assertEqual(c["optim"]["warmup_steps"], 1000)
        self.assertEqual(c["optim"]["max_epochs"], 100)
        self.assertEqual(c["optim"]["patience"], 15)
        self.assertEqual(c["optim"]["batch_size"], 512)
        self.assertEqual(c["data"]["split"], [0.70, 0.10, 0.20])
        self.assertEqual(c["data"]["mash_jaccard_threshold"], 0.95)

    def test_every_table7_variant_has_a_config(self):
        for vid in TABLE7:
            self.assertTrue((ROOT / f"configs/ablations/ablation_{vid}.yaml").exists(), vid)

    def test_ablation_cohorts_match_table7(self):
        for vid, (label, ds, *_ ) in TABLE7.items():
            c = load_config(ROOT / f"configs/ablations/ablation_{vid}.yaml")
            self.assertEqual(c["dataset"], ds, vid)
            self.assertEqual(c["label"], label, vid)

    def test_override_parsing(self):
        o = parse_set(["optim.lr=1e-4", "model.use_rwpe=false", "model.d_model=128"])
        self.assertEqual(o["optim"]["lr"], 1e-4)
        self.assertIs(o["model"]["use_rwpe"], False)
        self.assertEqual(o["model"]["d_model"], 128)


class TestManuscriptConsistency(unittest.TestCase):
    def test_table6_shape(self):
        self.assertEqual(len(TABLE6), 7)
        for meth, per in TABLE6.items():
            self.assertEqual(sorted(per), sorted(DATASETS))
            for ds in DATASETS:
                self.assertIn(THIRD_METRIC[ds], per[ds])

    def test_table8_ci_reproduces(self):
        for ds, met, (m1, s1), (m2, s2), diff, lo, hi in TABLE8:
            rlo, rhi = S.ci_from_sds(m1, s1, m2, s2, n=10)
            self.assertAlmostEqual(round(rlo, 3), lo, places=9, msg=f"{ds}/{met}")
            self.assertAlmostEqual(round(rhi, 3), hi, places=9, msg=f"{ds}/{met}")

    def test_verifier_exits_clean(self):
        r = subprocess.run([sys.executable, str(ROOT / "verify_against_manuscript.py")],
                           capture_output=True, text=True, cwd=ROOT)
        self.assertEqual(r.returncode, 0, r.stdout[-2000:])
        self.assertIn("0 failed", r.stdout)

    def test_generate_expected_writes_all_tables(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            r = subprocess.run([sys.executable, str(ROOT / "generate_expected.py"),
                                "--out", d], capture_output=True, text=True, cwd=ROOT)
            self.assertEqual(r.returncode, 0, r.stderr)
            for f in ("expected_table6.csv", "expected_table7.csv",
                      "expected_table8.csv", "expected_table9.csv",
                      "expected_values.json"):
                self.assertTrue((Path(d) / f).exists(), f)


class TestModel(unittest.TestCase):
    def setUp(self):
        try:
            import torch  # noqa: F401
        except ImportError:
            self.skipTest("torch not installed")

    def _batch(self, n=64, f=16, rw=20, device="cpu"):
        import torch
        g = torch.Generator().manual_seed(0)
        nt = torch.arange(n) % 4
        from src.model import NODE_TYPES, RELATION_TYPES
        return {
            "x_dict": {t: torch.randn(int((nt == i).sum()), f, generator=g)
                       for i, t in enumerate(NODE_TYPES)},
            "node_type": nt,
            "rw_landing": torch.rand(n, rw, generator=g),
            "edge_index_dict": {r: torch.randint(0, n, (2, 120), generator=g)
                                for r in RELATION_TYPES},
            "edge_weight_dict": {r: torch.rand(120, generator=g) for r in RELATION_TYPES},
            "label_index": torch.arange(24),
            "y": torch.randint(0, 541, (24,), generator=g),
            "pair_index": torch.randint(0, n, (2, 40), generator=g),
            "pair_label": torch.randint(0, 2, (40,), generator=g),
        }

    def _net(self, f=16, rw=20):
        from src.model import PanMetaGraph, NODE_TYPES
        return PanMetaGraph({t: f for t in NODE_TYPES}, d_model=32, n_heads=4,
                            n_layers=2, n_classes=541, rw_steps=rw)

    def test_forward_shapes(self):
        b = self._batch(); net = self._net()
        out = net(b)
        self.assertEqual(tuple(out["logits"].shape), (64, 541))
        self.assertEqual(tuple(out["p_transfer"].shape), (40,))

    def test_transfer_probability_in_unit_interval(self):
        out = self._net()(self._batch())
        self.assertTrue(bool((out["p_transfer"] >= 0).all() and (out["p_transfer"] <= 1).all()))

    def test_backward_touches_every_trainable_parameter(self):
        net = self._net(); b = self._batch()
        loss, parts = net.loss(net(b), b)
        loss.backward()
        dead = [n for n, p in net.named_parameters()
                if p.requires_grad and (p.grad is None or not bool(p.grad.abs().sum() > 0))]
        self.assertEqual(dead, [], f"no gradient reached: {dead}")
        self.assertGreater(parts["l_cls"], 0.0)

    def test_relation_weights_are_a_simplex(self):
        import torch
        net = self._net()
        w = torch.softmax(net.layers[0].attn.beta, dim=0)
        self.assertAlmostEqual(float(w.sum()), 1.0, places=5)

    def test_dropping_a_relation_changes_the_output(self):
        import torch
        net = self._net().eval()
        b = self._batch()
        full = net(b)["logits"]
        b2 = dict(b); b2["edge_index_dict"] = {k: v for k, v in b["edge_index_dict"].items()
                                               if k != "mge_link"}
        self.assertFalse(bool(torch.allclose(full, net(b2)["logits"])))

    def test_disabling_rwpe_changes_the_output(self):
        import torch
        net = self._net().eval()
        b = self._batch()
        b2 = dict(b); b2["rw_landing"] = None
        self.assertFalse(bool(torch.allclose(net(b)["logits"], net(b2)["logits"])))

    def test_mu_scales_the_transfer_term(self):
        net = self._net(); b = self._batch()
        out = net(b)
        _, p1 = net.loss(out, b)
        net.mu = 0.0
        _, p0 = net.loss(out, b)
        self.assertAlmostEqual(p1["loss"] - p0["loss"], 0.1 * p1["l_tr"], places=5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
