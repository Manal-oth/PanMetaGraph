#!/usr/bin/env python3
"""Aggregate completed runs into Tables 6, 7 and 8 and compare them with the
values reported in the manuscript.

    # aggregate whatever runs exist under results/
    python evaluate_all.py --results results --out tables

    # also run the paired tests and Holm correction for PanMetaGraph vs AMR-GNN
    python evaluate_all.py --results results --stats

Reads results/<variant>_<dataset>_seed<seed>/metrics.json (written by train.py).
Reports mean +/- SD over the seeds actually present and the signed difference
against the manuscript value for every cell, so a divergence is visible rather
than silently absorbed. Nothing is filled in for a run that is absent: missing
cells are listed as missing.

Requires numpy; torch is not needed.
"""
import argparse, csv, json
from collections import defaultdict
from pathlib import Path

import numpy as np

from manuscript_values import TABLE6, TABLE7, TABLE8, DATASETS, THIRD_METRIC, SECONDARY
from src.metrics import METRIC_LABELS
from src.stats import paired_t_test, paired_t_ci, holm_bonferroni

TOL = 0.005        # half of the last reported digit's step, for a 3-decimal table


def collect(results):
    runs = defaultdict(list)
    for f in sorted(Path(results).glob("*/metrics.json")):
        r = json.loads(f.read_text())
        runs[(r.get("variant", "full"), r["dataset"], r.get("method", "PanMetaGraph"))].append(r)
    return runs


def agg(vals):
    a = np.asarray(vals, float)
    return float(a.mean()), float(a.std(ddof=1)) if len(a) > 1 else 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="tables")
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--tolerance", type=float, default=TOL)
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    runs = collect(a.results)
    if not runs:
        print(f"no metrics.json under {a.results}/. Train first, e.g.\n"
              f"  bash run_ablation.sh --dataset D4 --seeds 0 1 2 3 4 5 6 7 8 9")
        return 1

    rows, deviations, missing = [], [], []
    for (variant, ds, method), rs in sorted(runs.items()):
        seeds = sorted(r["seed"] for r in rs)
        mets = ["auroc", "macro_f1", THIRD_METRIC[ds]] + SECONDARY
        for met in mets:
            vals = [r["test"][met] for r in rs if met in r["test"]]
            if not vals:
                continue
            m, s = agg(vals)
            ref = None
            if variant == "full" and method in TABLE6:
                ref = TABLE6[method][ds].get(met, (None,))[0]
            elif variant in TABLE7 and met in ("auroc", "macro_f1", "p_at_50"):
                idx = {"auroc": 2, "macro_f1": 4, "p_at_50": 6}[met]
                if TABLE7[variant][1] == ds:
                    ref = TABLE7[variant][idx]
            d = None if ref is None else round(m - ref, 4)
            rows.append({"variant": variant, "dataset": ds, "method": method,
                         "metric": METRIC_LABELS[met], "n_seeds": len(vals),
                         "seeds": " ".join(map(str, seeds)),
                         "mean": f"{m:.3f}", "sd": f"{s:.3f}",
                         "manuscript": "" if ref is None else f"{ref:.3f}",
                         "difference": "" if d is None else f"{d:+.4f}"})
            if d is not None and abs(d) > a.tolerance:
                deviations.append((variant, ds, method, METRIC_LABELS[met], m, ref, d))
            if len(vals) < 10:
                missing.append((variant, ds, method, METRIC_LABELS[met], len(vals)))

    with open(out / "observed_vs_manuscript.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"wrote {out}/observed_vs_manuscript.csv ({len(rows)} cells)")

    if a.stats:
        ours = {(r["dataset"], r["seed"]): r["test"]
                for (v, d, m), rs in runs.items() if v == "full" and m == "PanMetaGraph"
                for r in rs}
        base = {(r["dataset"], r["seed"]): r["test"]
                for (v, d, m), rs in runs.items() if v == "full" and m == "AMR-GNN"
                for r in rs}
        srows, pv = [], []
        for ds, met, *_ in TABLE8:
            seeds = sorted({s for (d, s) in ours if d == ds} & {s for (d, s) in base if d == ds})
            if len(seeds) < 3:
                continue
            x = [ours[(ds, s)][met] for s in seeds]
            y = [base[(ds, s)][met] for s in seeds]
            diff, t, p = paired_t_test(x, y)
            lo, hi = paired_t_ci(x, y)
            pv.append(p)
            srows.append({"dataset": ds, "metric": METRIC_LABELS[met],
                          "n_seeds": len(seeds), "diff": f"{diff:+.3f}",
                          "ci_low": f"{lo:.3f}", "ci_high": f"{hi:.3f}",
                          "t": f"{t:.2f}", "p_raw": f"{p:.2e}"})
        if srows:
            adj, rej = holm_bonferroni(pv)
            for r, ap_, rj in zip(srows, adj, rej):
                r["p_holm"] = f"{ap_:.2e}"; r["significant_at_0.05"] = rj
            with open(out / "statistical_tests.csv", "w", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=list(srows[0])); w.writeheader(); w.writerows(srows)
            print(f"wrote {out}/statistical_tests.csv ({len(srows)} comparisons, "
                  f"Holm family size {len(pv)})")
        else:
            print("paired tests skipped: matched-seed AMR-GNN runs not found under "
                  f"{a.results}/ (train it with --set method=AMR-GNN or supply its metrics.json)")

    if missing:
        print(f"\nincomplete cells (fewer than the 10 seeds reported in the paper): {len(missing)}")
        for m in missing[:20]:
            print(f"  {m[0]:>5} {m[1]} {m[2]:<15} {m[3]:<9} {m[4]} seed(s)")
    if deviations:
        print(f"\ncells differing from the manuscript by more than {a.tolerance}: {len(deviations)}")
        for v, ds, me, met, m, ref, d in deviations:
            print(f"  {v:>5} {ds} {me:<15} {met:<9} observed {m:.3f} vs reported {ref:.3f} ({d:+.4f})")
    else:
        print(f"\nevery reproduced cell is within {a.tolerance} of the reported value")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
