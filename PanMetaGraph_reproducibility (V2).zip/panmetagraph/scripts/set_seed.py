"""Deterministic seeding for every source of randomness used in a run.

Called by train.py and evaluate_all.py before any tensor is allocated, so that
the ten runs with seeds {0,...,9} are reproducible on fixed hardware.
"""
import os
import random


def set_seed(seed: int, deterministic: bool = True):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        if deterministic:
            os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
            try:
                torch.use_deterministic_algorithms(True, warn_only=True)
            except Exception:
                pass
    except ImportError:
        pass
    return seed


if __name__ == "__main__":
    import sys
    print("seeded with", set_seed(int(sys.argv[1]) if len(sys.argv) > 1 else 0))
